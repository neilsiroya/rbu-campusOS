import type { ExperienceStage } from '../experience/types.ts'
import { WebAudioEngine, type AudioChapter, type AudioEngine } from './webAudioEngine.ts'

const chapterForStage = (stage: ExperienceStage): AudioChapter => {
  if (stage === 'opening' || stage === 'interior') return 'opening'
  if (stage === 'gallery' || stage === 'photoViewer') return 'gallery'
  if (stage === 'letterTransition' || stage === 'letter') return 'letter'
  if (stage === 'finale' || stage === 'complete') return 'finale'
  return 'cover'
}

export class AudioController {
  private unlocked = false
  private resumeOnVisible = false
  private currentChapter: AudioChapter = 'cover'
  private previousStage: ExperienceStage | null = null
  private readonly engine: AudioEngine

  constructor(engine: AudioEngine = new WebAudioEngine()) {
    this.engine = engine
  }

  async unlockAndStart(): Promise<void> {
    if (this.unlocked) return
    this.unlocked = true
    try {
      await this.engine.startTheme()
      this.engine.setChapter(this.currentChapter)
      this.engine.playPaper()
    } catch {
      // The visual card remains usable if a browser denies audio for any reason.
    }
  }

  setChapterForStage(stage: ExperienceStage) {
    const chapter = chapterForStage(stage)
    this.currentChapter = chapter
    try { this.engine.setChapter(chapter) } catch { /* mix changes are an enhancement */ }
    if (stage === 'letterTransition' && this.previousStage !== 'letterTransition' && this.unlocked) {
      try { this.engine.playRibbon() } catch { /* tactile cue is optional */ }
    }
    this.previousStage = stage
  }

  playChime() {
    if (!this.unlocked) return
    try { this.engine.playChime() } catch { /* audio is an enhancement */ }
  }

  pauseForVisibility() {
    if (!this.unlocked) return
    this.resumeOnVisible = true
    try { this.engine.pauseTheme() } catch { /* preserve visual state */ }
  }

  resumeFromVisibility() {
    if (!this.resumeOnVisible || !this.unlocked) return
    this.resumeOnVisible = false
    void this.engine.resumeTheme().then(() => this.engine.setChapter(this.currentChapter)).catch(() => undefined)
  }

  resetAudio() {
    this.resumeOnVisible = false
    this.unlocked = false
    this.currentChapter = 'cover'
    this.previousStage = null
    try { this.engine.stopAll() } catch { /* reset remains safe */ }
  }
}

export const audioController = new AudioController()
