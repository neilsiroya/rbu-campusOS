export const COPY = {
  coverTitle: 'Happy Birthday, Mom',
  openingPrompt: 'Tap to open',
  interiorTitle: 'Happy Birthday, Mom',
  galleryIntro: 'A few of my favourite pictures of you.',
  letterLabel: 'For Mom',
  letter: {
    heading: 'Happy Birthday, Mom. ❤️',
    paragraphs: [
      "You're the strongest woman I've ever known, and the most beautiful example of what love, strength, and selflessness truly mean.",
      "Everything I am, and so much of what I hope to become, comes from you. Your strength, your kindness, your love, and the way you've raised me are things I'll admire for the rest of my life.",
      "If I become even half the person you are, I'll consider myself incredibly lucky.",
      'I love you more than words could ever express. Happy Birthday to the best mother in the world.',
    ],
    signoff: 'Forever your son. ❤️',
  },
  finale: {
    heading: 'Happy Birthday, Mom.',
    paragraphs: [
      "Thank you for being my strength, my home, and someone I'll always look up to.",
      "I hope life gives you back all the love you've spent your life giving to everyone around you.",
      "I love you more than I'll ever be able to put into words.",
    ],
    finalLine: 'Happy Birthday to the best mom in the world. ❤️',
  },
  microDetails: ['our strength', 'our home', 'our inspiration', 'love you, Mom'],
} as const
