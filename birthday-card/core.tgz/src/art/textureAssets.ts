export const TEXTURE_ASSETS = Object.freeze({
  // The art system intentionally uses procedural micro-texture so there are no
  // fragile runtime CDN texture requests. Photographs remain the only raster art.
  proceduralPaperFiber: 'procedural:paper-fiber',
  proceduralVellumNoise: 'procedural:vellum-noise',
} as const)

export const LOCAL_FONT_FAMILIES = Object.freeze({
  hero: 'Bodoni Moda',
  letter: 'Source Serif 4',
  ui: 'Manrope',
} as const)
