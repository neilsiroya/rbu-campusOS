import { ART_PALETTE } from './palette.ts'

export interface MaterialPreset {
  color: string
  roughness: number
  metalness: number
  transparent?: boolean
  opacity?: number
  transmission?: number
  thickness?: number
  clearcoat?: number
  clearcoatRoughness?: number
  side?: 'front' | 'double'
}

export const MATERIAL_PRESETS = Object.freeze({
  cottonPaper: { color: ART_PALETTE.ivory, roughness: 0.93, metalness: 0, clearcoat: 0.02, clearcoatRoughness: 0.95 },
  cardstock: { color: ART_PALETTE.cream, roughness: 0.86, metalness: 0, clearcoat: 0.04, clearcoatRoughness: 0.88 },
  vellum: { color: ART_PALETTE.vellum, roughness: 0.42, metalness: 0, transparent: true, opacity: 0.58, transmission: 0.5, thickness: 0.08, side: 'double' },
  champagneFoil: { color: ART_PALETTE.champagne, roughness: 0.24, metalness: 0.8, clearcoat: 0.32, clearcoatRoughness: 0.2 },
  photoPaper: { color: ART_PALETTE.photoEdge, roughness: 0.46, metalness: 0, clearcoat: 0.18, clearcoatRoughness: 0.38 },
  paperFlower: { color: ART_PALETTE.dustyBlush, roughness: 0.88, metalness: 0 },
  pressedFlower: { color: ART_PALETTE.oldRose, roughness: 0.98, metalness: 0, transparent: true, opacity: 0.88, side: 'double' },
  ribbon: { color: ART_PALETTE.dustyBlush, roughness: 0.62, metalness: 0, side: 'double' },
  thread: { color: ART_PALETTE.champagneSoft, roughness: 0.5, metalness: 0.18 },
  warmInk: { color: ART_PALETTE.warmInk, roughness: 0.72, metalness: 0 },
} as const satisfies Record<string, MaterialPreset>)
