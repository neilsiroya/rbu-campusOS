export const ART_PALETTE = Object.freeze({
  ivory: '#f3eadc',
  cream: '#eadbc7',
  vellum: '#f7efe4',
  dustyBlush: '#cf9ea1',
  oldRose: '#b7747e',
  burgundy: '#713845',
  sage: '#9aa38d',
  olive: '#65705d',
  champagne: '#b99a67',
  champagneSoft: '#cfb786',
  warmInk: '#513f35',
  warmShadow: '#40303b',
  charcoal: '#17120f',
  chocolate: '#251915',
  photoEdge: '#f8f0e4',
} as const)

export type ArtColorName = keyof typeof ART_PALETTE
