import { forwardRef, useMemo } from 'react'
import { CatmullRomCurve3, Vector3, type Group } from 'three'
import { ART_PALETTE } from '../palette'
import { AlmondLeaf, FoldedLeaf, FoldedPetal, PressedBloom, ScallopPetal, TeardropPetal } from './FloralPrimitives'

export type FloralClusterVariant = 'coverHero' | 'coverBalance' | 'interiorLeft' | 'interiorRight'

interface FloralClusterProps {
  variant: FloralClusterVariant
  position?: [number, number, number]
  rotation?: [number, number, number]
  scale?: number
}

function PaperBloom({ color, size = 1, style = 'couture' }: { color: string; size?: number; style?: 'couture' | 'open' | 'bud' }) {
  const count = style === 'open' ? 7 : style === 'bud' ? 4 : 6
  return (
    <group scale={size} name={`paper-bloom-${style}`}>
      {Array.from({ length: count }, (_, i) => {
        const angle = (i / count) * Math.PI * 2 + (style === 'couture' ? 0.16 : 0)
        const Component = i % 3 === 0 ? FoldedPetal : i % 2 === 0 ? ScallopPetal : TeardropPetal
        const radius = style === 'bud' ? 0.055 : 0.09 + (i % 2) * 0.018
        return (
          <Component
            key={i}
            color={i % 3 === 0 ? ART_PALETTE.ivory : color}
            materialMode="paper"
            scale={style === 'bud' ? 0.42 : 0.5 + (i % 3) * 0.045}
            position={[Math.cos(angle) * radius, Math.sin(angle) * radius, 0.025 + (i % 2) * 0.02]}
            rotation={[-0.12 + (i % 2) * 0.18, 0.08 * Math.sin(angle), angle - Math.PI / 2]}
          />
        )
      })}
      <mesh position={[0, 0, 0.072]} castShadow>
        <sphereGeometry args={[style === 'bud' ? 0.045 : 0.06, 14, 9]} />
        <meshStandardMaterial color={ART_PALETTE.burgundy} roughness={0.86} />
      </mesh>
    </group>
  )
}

function Stem({ points, color = ART_PALETTE.olive }: { points: [number, number, number][]; color?: string }) {
  const curve = useMemo(() => new CatmullRomCurve3(points.map((p) => new Vector3(...p))), [points])
  return (
    <mesh castShadow>
      <tubeGeometry args={[curve, 28, 0.009, 6, false]} />
      <meshStandardMaterial color={color} roughness={0.92} />
    </mesh>
  )
}

export const FloralCluster = forwardRef<Group, FloralClusterProps>(function FloralCluster(
  { variant, position = [0, 0, 0], rotation = [0, 0, 0], scale = 1 },
  ref,
) {
  if (variant === 'coverHero') {
    return (
      <group ref={ref} name="coverHero" position={position} rotation={rotation} scale={scale}>
        <Stem points={[[-0.05, -0.72, 0], [-0.2, -0.12, 0.035], [-0.58, 0.42, 0.02], [-0.92, 0.78, 0.01]]} />
        <Stem points={[[-0.08, -0.65, 0], [0.15, -0.12, 0.025], [0.3, 0.34, 0.01]]} color={ART_PALETTE.sage} />
        <PaperBloom color={ART_PALETTE.oldRose} size={1.05} style="couture" />
        <group position={[-0.48, 0.43, 0.05]} rotation={[0.08, -0.12, -0.45]}><PaperBloom color={ART_PALETTE.dustyBlush} size={0.75} style="open" /></group>
        <group position={[-0.83, 0.76, 0.035]} rotation={[0.18, 0.04, -0.8]}><PaperBloom color={ART_PALETTE.burgundy} size={0.52} style="bud" /></group>
        <PressedBloom position={[0.22, 0.3, 0.026]} scale={0.7} color={ART_PALETTE.oldRose} />
        <AlmondLeaf position={[-0.26, -0.24, 0.018]} scale={0.68} rotation={[0.08, -0.08, -0.78]} color={ART_PALETTE.olive} />
        <FoldedLeaf position={[-0.54, 0.2, 0.06]} scale={0.73} rotation={[-0.08, 0.22, 0.74]} color={ART_PALETTE.sage} />
        <AlmondLeaf position={[-0.76, 0.55, 0.032]} scale={0.62} rotation={[0.08, -0.1, -0.9]} color={ART_PALETTE.olive} />
        <FoldedLeaf position={[0.16, 0.04, 0.07]} scale={0.58} rotation={[0.18, 0.24, 0.62]} color={ART_PALETTE.sage} />
        <TeardropPetal position={[0.42, 0.2, 0.1]} scale={0.38} rotation={[0.18, 0.2, 1.1]} materialMode="vellum" color={ART_PALETTE.vellum} />
        <FoldedPetal position={[-0.96, 0.92, 0.085]} scale={0.34} rotation={[0.2, -0.15, -0.2]} materialMode="pressed" color={ART_PALETTE.oldRose} />
      </group>
    )
  }

  if (variant === 'coverBalance') {
    return (
      <group ref={ref} name="coverBalance" position={position} rotation={rotation} scale={scale}>
        <Stem points={[[0, -0.32, 0], [0.06, 0, 0.02], [0.22, 0.28, 0.01]]} />
        <PaperBloom color={ART_PALETTE.burgundy} size={0.54} style="bud" />
        <AlmondLeaf position={[0.19, 0.17, 0.025]} scale={0.52} rotation={[0.08, 0.08, 0.78]} />
        <FoldedLeaf position={[-0.12, -0.14, 0.055]} scale={0.47} rotation={[0.12, -0.12, -0.72]} color={ART_PALETTE.olive} />
        <ScallopPetal position={[0.34, 0.24, 0.08]} scale={0.3} rotation={[0.1, 0.2, 0.7]} materialMode="vellum" />
      </group>
    )
  }

  if (variant === 'interiorLeft') {
    return (
      <group ref={ref} name="interiorLeft" position={position} rotation={rotation} scale={scale}>
        <Stem points={[[0.05, -0.55, 0], [-0.12, -0.08, 0.03], [-0.38, 0.4, 0.02]]} />
        <PaperBloom color={ART_PALETTE.oldRose} size={0.75} style="open" />
        <PressedBloom position={[-0.32, 0.36, 0.045]} scale={0.55} />
        <AlmondLeaf position={[-0.15, -0.2, 0.03]} rotation={[0.08, 0, -0.65]} scale={0.6} />
        <FoldedLeaf position={[-0.35, 0.18, 0.07]} rotation={[0.08, 0.2, 0.7]} scale={0.54} />
      </group>
    )
  }

  return (
    <group ref={ref} name="interiorRight" position={position} rotation={rotation} scale={scale}>
      <Stem points={[[0, -0.42, 0], [0.1, -0.02, 0.02], [0.34, 0.35, 0.02]]} color={ART_PALETTE.sage} />
      <PaperBloom color={ART_PALETTE.burgundy} size={0.62} style="couture" />
      <FoldedLeaf position={[0.25, 0.2, 0.045]} rotation={[0.1, -0.15, 0.84]} scale={0.55} />
      <TeardropPetal position={[-0.26, 0.14, 0.07]} rotation={[0.18, 0.12, -0.85]} scale={0.34} materialMode="vellum" />
    </group>
  )
})
