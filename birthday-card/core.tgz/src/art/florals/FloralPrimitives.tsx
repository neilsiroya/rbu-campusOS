import { useMemo } from 'react'
import { DoubleSide, Shape } from 'three'
import { ART_PALETTE } from '../palette'
import { MATERIAL_PRESETS } from '../materials'

export type FloralMaterialMode = 'paper' | 'vellum' | 'pressed'
// materialMode choices: paper, vellum, pressed

interface PrimitiveProps {
  color?: string
  materialMode?: FloralMaterialMode
  scale?: number
  rotation?: [number, number, number]
  position?: [number, number, number]
}

function usePetalShape(kind: 'teardrop' | 'scallop' | 'folded') {
  return useMemo(() => {
    const s = new Shape()
    s.moveTo(0, -0.12)
    if (kind === 'teardrop') {
      s.bezierCurveTo(-0.2, -0.02, -0.2, 0.28, 0, 0.5)
      s.bezierCurveTo(0.2, 0.28, 0.2, -0.02, 0, -0.12)
    } else if (kind === 'scallop') {
      s.bezierCurveTo(-0.26, 0.02, -0.18, 0.34, -0.03, 0.44)
      s.bezierCurveTo(0.04, 0.52, 0.2, 0.35, 0.24, 0.18)
      s.bezierCurveTo(0.27, 0.03, 0.14, -0.06, 0, -0.12)
    } else {
      s.bezierCurveTo(-0.16, 0.04, -0.13, 0.34, 0, 0.48)
      s.bezierCurveTo(0.1, 0.32, 0.2, 0.08, 0, -0.12)
    }
    return s
  }, [kind])
}

function useLeafShape(folded: boolean) {
  return useMemo(() => {
    const s = new Shape()
    s.moveTo(-0.02, -0.28)
    s.bezierCurveTo(-0.23, -0.08, -0.22, 0.2, 0, 0.38)
    s.bezierCurveTo(folded ? 0.12 : 0.22, 0.18, folded ? 0.1 : 0.22, -0.12, -0.02, -0.28)
    return s
  }, [folded])
}

function Material({ mode, color }: { mode: FloralMaterialMode; color?: string }) {
  if (mode === 'vellum') {
    const p = MATERIAL_PRESETS.vellum
    return <meshPhysicalMaterial color={color ?? p.color} roughness={p.roughness} metalness={p.metalness} transparent opacity={p.opacity} transmission={p.transmission} thickness={p.thickness} side={DoubleSide} />
  }
  if (mode === 'pressed') {
    const p = MATERIAL_PRESETS.pressedFlower
    return <meshStandardMaterial color={color ?? p.color} roughness={p.roughness} metalness={p.metalness} transparent opacity={p.opacity} side={DoubleSide} />
  }
  const p = MATERIAL_PRESETS.paperFlower
  return <meshStandardMaterial color={color ?? p.color} roughness={p.roughness} metalness={p.metalness} side={DoubleSide} />
}

function PetalMesh({ kind, materialMode = 'paper', color, scale = 1, rotation = [0, 0, 0], position = [0, 0, 0] }: PrimitiveProps & { kind: 'teardrop' | 'scallop' | 'folded' }) {
  const shape = usePetalShape(kind)
  return (
    <mesh position={position} rotation={rotation} scale={scale} castShadow receiveShadow>
      <shapeGeometry args={[shape, 20]} />
      <Material mode={materialMode} color={color} />
    </mesh>
  )
}

export function TeardropPetal(props: PrimitiveProps) { return <PetalMesh {...props} kind="teardrop" /> }
export function ScallopPetal(props: PrimitiveProps) { return <PetalMesh {...props} kind="scallop" /> }
export function FoldedPetal(props: PrimitiveProps) { return <PetalMesh {...props} kind="folded" /> }

export function AlmondLeaf({ color = ART_PALETTE.sage, materialMode = 'paper', scale = 1, rotation = [0, 0, 0], position = [0, 0, 0] }: PrimitiveProps) {
  const shape = useLeafShape(false)
  return <mesh position={position} rotation={rotation} scale={scale} castShadow><shapeGeometry args={[shape, 16]} /><Material mode={materialMode} color={color} /></mesh>
}

export function FoldedLeaf({ color = ART_PALETTE.olive, materialMode = 'paper', scale = 1, rotation = [0, 0, 0], position = [0, 0, 0] }: PrimitiveProps) {
  const shape = useLeafShape(true)
  return <mesh position={position} rotation={rotation} scale={scale} castShadow><shapeGeometry args={[shape, 16]} /><Material mode={materialMode} color={color} /></mesh>
}

export function PressedBloom({ color = ART_PALETTE.oldRose, scale = 1, rotation = [0, 0, 0], position = [0, 0, 0] }: PrimitiveProps) {
  const petals = 5
  return (
    <group position={position} rotation={rotation} scale={scale} name="pressed-bloom">
      {Array.from({ length: petals }, (_, i) => (
        <TeardropPetal key={i} materialMode="pressed" color={color} scale={0.42} rotation={[0.1, -0.06, (i / petals) * Math.PI * 2]} position={[Math.cos((i / petals) * Math.PI * 2) * 0.08, Math.sin((i / petals) * Math.PI * 2) * 0.08, i * 0.002]} />
      ))}
      <mesh position={[0, 0, 0.015]}><sphereGeometry args={[0.04, 12, 8]} /><meshStandardMaterial color={ART_PALETTE.burgundy} roughness={0.92} /></mesh>
    </group>
  )
}
